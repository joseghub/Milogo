﻿Public Class Form1
    Private interpreter As New Interpreter()
    Private WithEvents canvas As PictureBox
    Private g As Graphics
    Private bmp As Bitmap

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Crear área de dibujo
        bmp = New Bitmap(800, 600)
        canvas = New PictureBox With {
            .Location = New Point(10, 50),
            .Size = New Size(800, 600),
            .Image = bmp,
            .BorderStyle = BorderStyle.FixedSingle
        }
        Controls.Add(canvas)

        ' Preparar gráficos
        g = Graphics.FromImage(bmp)
        g.Clear(Color.White)

        interpreter.Inicializar(g, canvas)
    End Sub

    Private Sub EjecutarComando(sender As Object, e As EventArgs)
        Dim comando As String = TextBox1.Text.Trim()
        interpreter.Ejecutar(comando)
        canvas.Refresh()
    End Sub
End Class