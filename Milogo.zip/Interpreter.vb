﻿Public Class Interpreter
    Private g As Graphics
    Private canvas As PictureBox
    Private posX As Single = 400
    Private posY As Single = 300
    Private angulo As Single = 0
    Private plumaAbajo As Boolean = True
    Private colorPluma As Color = Color.Black
    Private fondo As Color = Color.White

    Public Sub Inicializar(graf As Graphics, lienzo As PictureBox)
        g = graf
        canvas = lienzo
    End Sub

    Public Sub Ejecutar(comando As String)
        Dim partes = comando.Split(" "c)
        If partes.Length = 0 Then Return
        If g Is Nothing Then Exit Sub

        Dim cmd = partes(0).ToUpper()

        Select Case cmd
            Case "AVANZA"
                If partes.Length >= 2 AndAlso IsNumeric(partes(1)) Then
                    Dim dist = CSng(partes(1))
                    Dim nuevoX = posX + dist * Math.Cos(angulo * Math.PI / 180)
                    Dim nuevoY = posY + dist * Math.Sin(angulo * Math.PI / 180)
                    If plumaAbajo Then
                        Using p As New Pen(colorPluma, 2)
                            g.DrawLine(p, posX, posY, nuevoX, nuevoY)
                        End Using
                    End If
                    posX = nuevoX
                    posY = nuevoY
                End If

            Case "GIRA"
                If partes.Length >= 2 AndAlso IsNumeric(partes(1)) Then
                    angulo += CSng(partes(1))
                End If

            Case "CÍRCULO"
                If partes.Length >= 2 AndAlso IsNumeric(partes(1)) Then
                    Dim r = CSng(partes(1))
                    If plumaAbajo Then
                        Using p As New Pen(colorPluma, 2)
                            g.DrawEllipse(p, posX - r, posY - r, r * 2, r * 2)
                        End Using
                    End If
                End If

            Case "TEXTO"
                If partes.Length >= 2 Then
                    Dim texto = comando.Substring(6).Trim("""")
                    Using b As New SolidBrush(colorPluma)
                        g.DrawString(texto, New Font("Arial", 12), b, posX, posY)
                    End Using
                End If

            Case "COLOR"
                If partes.Length >= 4 Then
                    Dim r = CInt(partes(1))
                    Dim g_ = CInt(partes(2))
                    Dim b = CInt(partes(3))
                    colorPluma = Color.FromArgb(r, g_, b)
                End If

            Case "FONDO"
                If partes.Length >= 4 Then
                    Dim r = CInt(partes(1))
                    Dim g_ = CInt(partes(2))
                    Dim b = CInt(partes(3))
                    fondo = Color.FromArgb(r, g_, b)
                    Me.g.Clear(fondo)
                End If

            Case "LEVANTA"
                plumaAbajo = False

            Case "BAJA"
                plumaAbajo = True
        End Select
    End Sub


End Class