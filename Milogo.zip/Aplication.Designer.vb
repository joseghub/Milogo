﻿Namespace My
    Partial Friend Class MyApplication
    End Class
End Namespace