﻿Imports System.Reflection

<Assembly: AssemblyTitle("MiLogo")>
<Assembly: AssemblyDescription("Intérprete Logo básico")>
<Assembly: AssemblyCompany("TuNombre")>
<Assembly: AssemblyProduct("MiLogo")>
<Assembly: AssemblyVersion("1.0.0.0")>